import pygame

pygame.init()
size = [1920, 1080]
window = pygame.display.set_mode(size)
pygame.display.set_caption('Меню')
clock = pygame.time.Clock()
menu_items = ['Play', 'About game', 'Quit']
font = pygame.font.Font('пикчи/fonts/advanced_pixel-7.ttf', 70)
cursor = pygame.transform.scale(pygame.image.load('пикчи/fantasy/stick1.png'), [20, 20])
pygame.mouse.set_visible(False)
x = 215
y = size[1]//3
dy = 160
menu_items_rect = []
run = True
while run:
    window.fill([145, 46, 50])
    menu_items_rect.clear()
    for i in range(len(menu_items)):
        menu_items_rect.append(pygame.Rect(x, y+i*dy, 200, 80))
        pygame.draw.rect(window, [255, 242, 0], menu_items_rect[i], 3)
        text = font.render(menu_items[i], True, [255, 242, 0])
        text_rect = text.get_rect(center = menu_items_rect[i].center)
        window.blit(text, text_rect)
        text_rect = menu_items
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                pos = pygame.mouse.get_pos()
                for i in range(len(menu_items_rect)):
                    if menu_items_rect[i].collidepoint(pos):
                        print(menu_items[i])
                        if i == 0:
                            import TRUE59
                            TRUE59.game()
                        elif i == 1:
                            pass
                    elif i == 2:
                        run = False
    if pygame.mouse.get_focused():
        pos = pygame.mouse.get_pos()
        window.blit(cursor, pos)

    clock.tick(60)
    pygame.display.flip()
pygame.quit()
quit()

import random, pygame

class Enemy:
    def __init__(self, x, y):
        self.pic = None
        self.rect = None
        self.speed = 3
        self.maximum_health = random.randint(3, 5)
        self.current_health = self.maximum_health
        self.health_bar_length = None
        self.health_ratio = None
        self.choice_picture(x, y)

    def choice_picture(self, x, y):
        enemies_pic = []
        for i in range(1, 5):
            enemies_pic.append(pygame.transform.scale(pygame.image.load('enemies/pumpkin' + str(i) + '.png'), [50, 50]))
        self.pic = random.choice(enemies_pic)
        self.rect = self.pic.get_rect(topleft=(x, y))
        self.health_bar_length = self.pic.get_width()
        self.health_ratio = self.current_health/self.health_bar_length

    def move(self):
        self.rect.x -= self.speed

    def draw(self, screen):
        screen.blit(self.pic, self.rect)

    def draw_health(self, screen):
        width_health = self.current_health/self.health_ratio
        pygame.draw.rect(screen, [255, 0, 0], [self.rect.x, self.rect.y - 10, self.health_bar_length, 5])
        pygame.draw.rect(screen, [0, 255, 0], [self.rect.x, self.rect.y - 10, width_health, 5])

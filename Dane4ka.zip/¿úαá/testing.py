#импортнутое
import pygame
import random
import time
import math
from pygame.color import THECOLORS
pygame.init()
#экран
width = 1920
height = 1080
size = [1920, 1080]
window = pygame.display.set_mode(size)
clock = pygame.time.Clock()
FPS = 50
pygame.display.set_caption('wizard')
run = True
#фон
bg0 = pygame.image.load('пикчи/фон.jpg')
bg = pygame.transform.scale(bg0, (size))
bg_rect = bg.get_rect(center=(width // 2, height // 2))
center_x = width / 2
center_y = height / 2
bg_speed = 6
#здоровье
width_hp = 60
height_hp = 10
health = 100
max_health = 100
alive = True
#манна
mann_x = 0
mann_y = 0
#персонаж
player_image = pygame.image.load('пикчи/гг/character.png')
player_rect = player_image.get_rect(center=(width / 2, height / 2))
player = pygame.transform.scale(player_image, (64, 100))
#враги
skeleton_alive = True
enemy_speed = 2
enemies = []
skeleton_image = pygame.image.load('пикчи/skeleton/idle2.png')
skeleton = pygame.transform.scale(skeleton_image, (80, 90))
skeleton_hp = 20
last_hit_time = 0
cooldown_duration = 1000

class Enemy:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.alive = True
        self.hp = 20

#спавн
spawn_side = random.choice(["left", "right", "top", "bottom"])
if spawn_side == "left":
    skeleton_x = random.randint(-100, 0)
    skeleton_y = random.randint(0, height)
elif spawn_side == "right":
    skeleton_x = random.randint(width, width + 100)
    skeleton_y = random.randint(0, height)
elif spawn_side == "top":
    skeleton_x = random.randint(0, width)
    skeleton_y = random.randint(-100, 0)
else:  # "bottom"
    skeleton_x = random.randint(0, width)
    skeleton_y = random.randint(height, height + 100)
enemy_spawn_time = 0
first_enemy_spawn_time = pygame.time.get_ticks()
#пули
bullet_speed = 20
player_bullets = []
last_player_shot_time = 0
player_shot_cooldown = 2000
bullet_image = pygame.image.load('пикчи/bullet.png')
bullet = pygame.transform.scale(bullet_image, (40, 40))
kryst = pygame.image.load('пикчи/$krystal$.png')
kryst_x = 0
kryst_y = 0
#движения персонажа
hero_image_number = 0
right01 = pygame.image.load('пикчи/гг/right1.png')
right02 = pygame.image.load('пикчи/гг/right2.png')
right03 = pygame.image.load('пикчи/гг/right3.png')
right04 = pygame.image.load('пикчи/гг/right4.png')
left01 = pygame.image.load('пикчи/гг/left1.png')
left02 = pygame.image.load('пикчи/гг/left2.png')
left03 = pygame.image.load('пикчи/гг/left3.png')
left04 = pygame.image.load('пикчи/гг/left4.png')
right1 = pygame.transform.scale(right01, (64, 100))
right2 = pygame.transform.scale(right02, (64, 100))
right3 = pygame.transform.scale(right03, (64, 100))
right4 = pygame.transform.scale(right04, (64, 100))
left1 = pygame.transform.scale(left01, (64, 100))
left2 = pygame.transform.scale(left02, (64, 100))
left3 = pygame.transform.scale(left03, (64, 100))
left4 = pygame.transform.scale(left04, (64, 100))
walk_right = [right1, right2, right3, right4]
walk_left = [left1, left2, left3, left4]
#функции
def move_character(): #анимации персонажа
    left = False
    right = False
    global hero_image_number
    global alive
    global skeleton_x, skeleton_y
    global kryst_x, kryst_y
    alive == True
    if width_hp == 0:
        alive = False
    for enemy in enemies:
        if pygame.Rect(player_rect).colliderect((enemy.x, enemy.y, skeleton.get_width(), skeleton.get_height())):
            if alive:
                if keys[pygame.K_a] and keys[pygame.K_w]:
                    left = True
                    right = False
                    bg_rect.x += bg_speed
                    bg_rect.y += bg_speed
                    skeleton_x += enemy_speed
                    skeleton_y += enemy_speed
                    hero_image_number += 1
                elif keys[pygame.K_a] and keys[pygame.K_s]:
                    left = True
                    right = False
                    bg_rect.x += bg_speed
                    bg_rect.y -= bg_speed
                    skeleton_x += enemy_speed
                    skeleton_y -= enemy_speed
                    hero_image_number += 1
                elif keys[pygame.K_d] and keys[pygame.K_w]:
                    left = False
                    right = True
                    bg_rect.x -= bg_speed
                    bg_rect.y += bg_speed
                    skeleton_x -= enemy_speed
                    skeleton_y += enemy_speed
                    hero_image_number += 1
                elif keys[pygame.K_d] and keys[pygame.K_s]:
                    left = False
                    right = True
                    bg_rect.x -= bg_speed
                    bg_rect.y -= bg_speed
                    skeleton_x -= enemy_speed
                    skeleton_y -= enemy_speed
                    hero_image_number += 1
                elif keys[pygame.K_a]:
                    left = True
                    right = False
                    bg_rect.x += bg_speed
                    skeleton_x += enemy_speed
                    hero_image_number += 1
                elif keys[pygame.K_d]:
                    left = False
                    right = True
                    bg_rect.x -= bg_speed
                    skeleton_x -= enemy_speed
                    hero_image_number += 1
                elif keys[pygame.K_w]:
                    left = False
                    right = True
                    bg_rect.y += bg_speed
                    skeleton_y += enemy_speed
                    hero_image_number += 1
                elif keys[pygame.K_s]:
                    left = True
                    right = False
                    bg_rect.y -= bg_speed
                    skeleton_y -= enemy_speed
                    hero_image_number += 1
                else:
                    window.blit(player, player_rect)
                    pygame.display.flip()
                if hero_image_number > 39:
                    hero_image_number = 0
                if left:
                    window.blit(walk_left[hero_image_number // 10], (912, 456))
                if right:
                    window.blit(walk_right[hero_image_number // 10], (912, 456))
            else:
                pass

def Health_Bar(): #полоска здоровья
    pygame.draw.rect(window, ('red'), (912, 580, width_hp, height_hp))
def mann_bar():
    pygame.draw.rect(window, ('blue'), (0, 0, 0, 0))
def player_shoot(): #стрельба игрока
    global last_player_shot_time
    global bullet
    global skeleton_hp
    global skeleton_alive
    direction_x = (skeleton_x + 30) - (center_x - 50)
    direction_y = (skeleton_y + 30) - (center_y - 50)
    length = math.sqrt(direction_x**2 + direction_y**2)
    if length != 0:
        direction_x /= length
        direction_y /= length
    current_time = pygame.time.get_ticks()
    if current_time - last_player_shot_time >= player_shot_cooldown:
        player_bullets.append([(center_x - 50), (center_y - 50), direction_x, direction_y, bullet_speed])
        last_player_shot_time = current_time
    for bullet_info in player_bullets:
        bullet_info[0] += bullet_info[2] * bullet_info[4]
        bullet_info[1] += bullet_info[3] * bullet_info[4]
        window.blit(bullet, (bullet_info[0], bullet_info[1]))
        bullet_rect = pygame.Rect(bullet_info[0], bullet_info[1], bullet.get_width(), bullet.get_height())
        skeleton_rect = pygame.Rect(skeleton_x, skeleton_y, skeleton.get_width(), skeleton.get_height())
        if bullet_rect.colliderect(skeleton_rect):
            skeleton_hp -= 10
            player_bullets.remove(bullet_info)
    if skeleton_hp == 0:
        skeleton_alive = False
def timer():
    elapsed_time = pygame.time.get_ticks() // 1000
    minutes = elapsed_time // 60
    seconds = elapsed_time % 60
    time_font = pygame.font.Font('пикчи/fonts/advanced_pixel-7.ttf', 72)
    time_text = time_font.render(f"{minutes:02d}:{seconds:02d}", True, pygame.Color('white'))
    window.blit(time_text, (900, 90))
def skeleton_work():
    global kryst_x, kryst_y
    global width_hp
    global last_hit_time
    global cooldown_duration
    global enemies

    current_time = pygame.time.get_ticks()

    # Управление существующими врагами
    for enemy in enemies:
        if enemy.alive:
            direction_x = (center_x - 50) - enemy.x
            direction_y = (center_y - 50) - enemy.y
            length = math.sqrt(direction_x ** 2 + direction_y ** 2)
            if length != 0:
                direction_x /= length
                direction_y /= length
            enemy.x += direction_x * enemy_speed
            enemy.y += direction_y * enemy_speed
            window.blit(skeleton, (enemy.x, enemy.y))

            if length < 40 and (current_time - last_hit_time) >= cooldown_duration:
                width_hp -= 10
                last_hit_time = current_time

            if length <= 1000:
                player_shoot()
        else:
            window.blit(kryst, (enemy.x, enemy.y))

    # Добавление новых врагов при необходимости
    if len(enemies) < 5:  # Измените этот порог по вашему усмотрению
        spawn_enemy()

def spawn_enemy():
    global enemies

    spawn_side = random.choice(["left", "right", "top", "bottom"])
    if spawn_side == "left":
        enemy_x = random.randint(-100, 0)
        enemy_y = random.randint(0, height)
    elif spawn_side == "right":
        enemy_x = random.randint(width, width + 100)
        enemy_y = random.randint(0, height)
    elif spawn_side == "top":
        enemy_x = random.randint(0, width)
        enemy_y = random.randint(-100, 0)
    else:  # "bottom"
        enemy_x = random.randint(0, width)
        enemy_y = random.randint(height, height + 100)

    new_enemy = Enemy(enemy_x, enemy_y)
    enemies.append(new_enemy)

while run:
    keys = pygame.key.get_pressed()
    window.fill('black')
    window.blit(bg, bg_rect)
    window.blit(bg, [bg_rect.x - width, bg_rect.y])
    window.blit(bg, [bg_rect.x, bg_rect.y])
    window.blit(bg, [bg_rect.x + width, bg_rect.y])
    timer()
    Health_Bar()
    mann_bar()
    move_character()
    skeleton_work()
    pygame.display.flip()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
    pygame.display.flip()
clock.tick(FPS)
pygame.quit()
quit()

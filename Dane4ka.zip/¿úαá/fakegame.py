import pygame, math, random
from enemy_class import Enemy
def main_game():
    pygame.init()
    from pygame.color import THECOLORS

    size = [618, 359]
    window = pygame.display.set_mode(size)
    pygame.display.set_icon(pygame.image.load('enemies/pumpkin_icon.png'))
    pygame.display.set_caption('Halloween')
    bg = pygame.image.load('bg.png')
    walkRight = [pygame.image.load('right/right1.png'), pygame.image.load('right/right2.png'),
                 pygame.image.load('right/right3.png'), pygame.image.load('right/right4.png')]
    walkLeft = []
    for i in range(1, 5):
        walkLeft.append(pygame.image.load('left/left' + str(i) + '.png'))
    player_stand = pygame.image.load("stand.png")
    player_stand.set_colorkey([255, 255, 255])
    animCount = 0
    bg_x = 0
    bg_y = 0
    bg_speed = 2
    bg_width = bg.get_width()
    player_x = 300
    player_y = 250
    player_speed = 5
    left = False
    right = False
    is_jump = False
    jump_count = 10
    clock = pygame.time.Clock()
    player_width = player_stand.get_width()
    player_height = player_stand.get_height()
    run = True
    all_bullets = []
    cursor = pygame.transform.scale(pygame.image.load('cursor.png'), [20, 20])
    pygame.mouse.set_visible(False)
    SPEED = 10
    snowball = pygame.transform.scale(pygame.image.load('snowball.png'), [15, 15])


    enemies_x = size[0] + 5
    enemies_y = 250
    all_enemies = []

    pygame.time.set_timer(pygame.USEREVENT, 3000)
    game_over = False
    game_over_pic = pygame.transform.scale(pygame.image.load('halloween.png'), size)
    score = 0
    score_font = pygame.font.Font('fonts/Pyrite Crypt.ttf', 30)
    game_over_font = pygame.font.Font('fonts/BlackWidow.ttf', 55)
    game_over_text = game_over_font.render('Press Enter to restart the game', True, [255, 255, 255])
    score_text = score_font.render(str(score), True, [6, 48, 64])
    treat = pygame.transform.scale(pygame.image.load('enemies/treat.png'), [50, 50])
    while run:
        keys = pygame.key.get_pressed()
        if game_over:
            window.blit(game_over_pic, [0, 0])
            text_rect = game_over_text.get_rect(center=window.get_rect().center)
            window.blit(game_over_text, text_rect)
            if keys[pygame.K_RETURN]:
                game_over = False
                player_x = 300
                player_y = 250
                score = 0
                all_enemies.clear()
                all_bullets.clear()
        else:

            window.blit(bg, [bg_x - bg_width, bg_y])
            window.blit(bg, [bg_x, bg_y])
            window.blit(bg, [bg_x + bg_width, bg_y])

            if bg_x <= -bg_width:
                bg_x = 0
            treat_rect = treat.get_rect(topright=(size[0] - 5, 5))
            window.blit(treat, treat_rect)
            score_rect = score_text.get_rect(centerx=treat_rect.centerx, centery=treat_rect.centery + 10)
            window.blit(score_text, score_rect)

            if right:
                window.blit(walkRight[animCount], [player_x, player_y])
                bg_x -= bg_speed
            elif left:
                window.blit(walkLeft[animCount], [player_x, player_y])
                bg_x += bg_speed
            else:
                window.blit(player_stand, [player_x, player_y])

            if animCount == len(walkRight) - 1:
                animCount = 0

            animCount += 1

            if all_enemies:
                for (i, enemy) in enumerate(all_enemies):
                    enemy.draw(window)
                    enemy.draw_health(window)
                    enemy.move()
                    if enemy.rect.x < 0:
                        all_enemies.pop(i)
                        continue
                    if enemy.rect.colliderect(player_stand.get_rect(topleft=(player_x, player_y))):
                        print('boom!')
                        game_over = True

            if keys[pygame.K_RIGHT] and player_x + player_width + 5 < size[0]:
                right = True
                left = False
                player_x += player_speed




            elif keys[pygame.K_LEFT] and player_x > 5:
                right = False
                left = True
                player_x -= player_speed
            else:
                right = False
                left = False
                animCount = 0
            if not is_jump:
                if keys[pygame.K_SPACE]:
                    is_jump = True
            else:       
                if jump_count >= -10:
                    if jump_count < 0:
                        player_y += (jump_count ** 2) / 4
                    else:
                        player_y -= (jump_count ** 2) / 4
                    jump_count -= 1
                else:
                    is_jump = False
                    jump_count = 10

            for (i, item) in enumerate(all_bullets):
                item[0] += item[2]  # pos_x += speed_x
                item[1] += item[3]  # pos_y -= speed_y
                if item[0] > size[0] or item[0] < 0 or item[1] < 0 or item[1] > size[1]:
                    all_bullets.pop(i)
                bullet_rect = snowball.get_rect(center=(item[0], item[1]))
                collide_index = bullet_rect.collidelist(all_enemies)
                if collide_index != -1:
                    all_bullets.pop(i)
                    all_enemies[collide_index].current_health -= 1
                    if all_enemies[collide_index].current_health < 0:
                        all_enemies.pop(collide_index)
                        score += 1
                        score_text = score_font.render(str(score), True, [6, 48, 64])

            for pos_x, pos_y, speed_x, speed_y in all_bullets:
                pos_x = int(pos_x)
                pos_y = int(pos_y)
                window.blit(snowball, snowball.get_rect(center=(pos_x, pos_y)))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            elif event.type == pygame.MOUSEBUTTONDOWN and not game_over:
                mouse_x, mouse_y = pygame.mouse.get_pos()

                distance_x = mouse_x - player_x + player_width // 2
                distance_y = mouse_y - player_y + player_height // 2

                angle = math.atan2(distance_y, distance_x)
                speed_x = SPEED * math.cos(angle)
                speed_y = SPEED * math.sin(angle)

                all_bullets.append([player_x + player_width // 2, player_y + player_height // 2, speed_x, speed_y])
            elif event.type == pygame.USEREVENT and not game_over:

                all_enemies.append(Enemy(enemies_x, enemies_y))
        if pygame.mouse.get_focused():
            pos = pygame.mouse.get_pos()
            window.blit(cursor, cursor.get_rect(center=pos))
        clock.tick(30)
        pygame.display.flip()


import random
#1
# total = 0
# minel = 101
# n = int(input('n = '))
# A = [[random.randint(1, 100) for j in range(n)] for i in range(n)]
#
# for i in range(n):
#     for j in range(n):
#         print(A[i][j], end=' ')
#     print()
# for i in range(n):
#     if A[i][n - i - 1] % 2 == 0:
#         total += A[i][n - i - 1]
# print(total)
# for i in range(n):
#     for j in range(i+1, n):
#         if A[i][j] < minel:
#             minel = A[i][j]
#             minjd = j
#             minid = i
# print(minjd)
# print(minid)
#2
# total = 0
# n = int(input('n = '))
# m = int(input('m = '))
# A = [[random.randint(1, 100) for j in range(n)] for i in range(m)]
# bid = 0
# b = A[0][0]
# for i in A:
#     print(i)
# for i in range(n):
#     for j in range(m):
#         if A[i][j] < b:
#             b = A[i][j]
#             bid = i
# print(bid)
# del A[bid]
# for i in A:
#     print(i)
#3
# def summ_count(total_i):
#     for j in range(1):
#         for i in range(m):
#             total_i += A[i][0]
#             if i == m:
#
#
#     print(total_i)
# n = int(input('n = '))
# m = int(input('m = '))
# b = int(input())
# total_i = 0
# A = [[random.randint(1, 100) for j in range(n)] for i in range(m)]
# for i in A:
#     print(i)
#
# summ_count(total_i)

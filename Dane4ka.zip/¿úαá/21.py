import random
#1
# n = int(input('n = '))
# m = int(input('m = '))
# k = int(input())
# A = [[random.randint(1, 100) for j in range(n)] for i in range(m)]
# max_k = 0
# min_k = 10000
# for i in A:
#     print(i)
# for i in range(m):
#     if A[i][k] > max_k:
#         max_k = A[i][k]
# for j in range(n):
#     if A[k][j] < min_k:
#         min_k = A[k][j]
#
# print('Сумма максимального элемента K-го столбца и минимального K-ой строки =', max_k + min_k)
#2
# n = int(input('n = '))
# m = int(input('m = '))
# A = [[random.randint(1, 10) for j in range(n)] for i in range(m)]
# totaled = []
# total = 1
# for i in A:
#     print(i)
# for i in range(m):
#     for j in range(n):
#         total *= A[i][j]
#         if j == (n-1):
#            totaled.append(total)
#            total = 1
# print(totaled)
# min_totaled = min(totaled)
# id_min_totaled = totaled.index(min_totaled)
# print('Минимальное произведение элементов =', min_totaled)
# print('Строка с минимальным произведением элементов =', id_min_totaled)
#3
# n = int(input('n = '))
# m = int(input('m = '))
# A = [[random.randint(1, 100) for j in range(n)] for i in range(m)]
# counter = 0
# max_counter = 0
# for i in A:
#     print(i)
# for i in range(m):
#     counter = 0
#     for j in range(n):
#         if A[i][j] % 3 == 0:
#             counter += 1
#     if counter > max_counter:
#         max_counter = counter
#         id_max_counter = i
# print(id_max_counter)
# A[0], A[id_max_counter] = A[id_max_counter], A[0]
# for i in A:
#     print(i)


import pygame
pygame.init()
size = [640, 740]
window = pygame.display.set_mode(size)
pygame.display.set_caption('Лабиринт')
file_name = 'map.txt'
run = True
nx = 0
ny = 100
dx = 64
dy = 64
road = pygame.image.load('road.png')  # дорога
wall = pygame.image.load('wall.png')  # стена
prize = pygame.image.load('prize.png')  # монетка
prize.set_colorkey([255, 242, 0])
player = pygame.image.load('player.png')  # персонаж
door = pygame.image.load('door.png')  # дверь (выход)
time = 20
font = pygame.font.Font('fonts/From Cartoon Blocks.ttf', 30)
pygame.display.set_icon(player)
timer_text = font.render('Time: ' + str(time), True, [255, 242, 0])
pygame.time.set_timer(pygame.USEREVENT, 1000)
game_over_pic = pygame.transform.scale(pygame.image.load('game_over.png'), size)
game_over = False
cursor = pygame.transform.scale(pygame.image.load('cursor.png'), [20, 20])
pygame.mouse.set_visible(False)
game_win_pic = pygame.transform.scale(pygame.image.load('game_win.jpg'), [640, 640])
win = False
level = 1
def read_file(file_name):
    all_prize = 0
    map_list = [0] * 10
    for i in range(10):
        map_list[i] = [0] * 10
    file = open(file_name, 'r')
    for row in range(10):
        s = file.readline()
        arr = s.split()
        for col in range(10):
            map_list[row][col] = int(arr[col])
            if map_list[row][col] == 3:
                all_prize += 1
    file.close()
    return map_list, all_prize


def draw_map(map_list, nx, ny, dx, dy):
    window.fill([177, 120, 62])
    p_row, p_col = 0, 0
    for row in range(10):
        for col in range(10):
            x = nx + col * dx
            y = ny + row * dy
            if map_list[row][col] == 0:  # стена
                window.blit(wall, [x, y])
            if map_list[row][col] == 1:  # дорога
                window.blit(road, [x, y])
            if map_list[row][col] == 2:  # персонаж
                window.blit(road, [x, y])
                window.blit(player, [x, y])
                p_row = row
                p_col = col
            if map_list[row][col] == 3:  # монетка
                window.blit(road, [x, y])
                window.blit(prize, [x, y])
            if map_list[row][col] == 4:  # дверь
                window.blit(door, [x, y])
    return p_row, p_col


def next_step(event, p_row, p_col):
    next_row, next_col = p_row, p_col
    if event.key == pygame.K_UP:
        if p_row > 0:
            next_row = p_row - 1
    elif event.key == pygame.K_DOWN:
        if p_row < 9:
            next_row = p_row + 1
    elif event.key == pygame.K_LEFT:
        if p_col > 0:
            next_col = p_col - 1
    elif event.key == pygame.K_RIGHT:
        if p_col < 9:
            next_col = p_col + 1
    return next_row, next_col


def move_player(map_list, p_row, p_col, next_row, next_col, score, win):
    if map_list[next_row][next_col] == 0:
        next_row = p_row
        next_col = p_col
    if map_list[next_row][next_col] == 1:
        map_list[next_row][next_col] = 2
        map_list[p_row][p_col] = 1
        p_row = next_row
        p_col = next_col
    if map_list[next_row][next_col] == 3:
        map_list[next_row][next_col] = 2
        map_list[p_row][p_col] = 1
        p_row = next_row
        p_col = next_col
        score += 1
    if map_list[next_row][next_col] == 4:
        if score == all_prize:
            map_list[next_row][next_col] = 2
            map_list[p_row][p_col] = 1
            p_row = next_row
            p_col = next_col
            print('win!')
            win = True
        else:
            next_row = p_row
            next_col = p_col
    return p_row, p_col, next_row, next_col, score, win

score = 0
map_list, all_prize = read_file('map'+str(level)+ '.txt')
score_text = font.render('Score: '+ str(score) + '/' + str(all_prize), True, [255, 242, 0])
print(all_prize)

clock = pygame.time.Clock()
p_row, p_col = 0, 0
next_row, next_col = 0, 0
while run:
    if not game_over:
        if not win:
            p_row, p_col = draw_map(map_list, nx, ny, dx, dy)
            window.blit(timer_text, [520, 10])
            window.blit(score_text, [10, 10])
        else:
            if level == 2:
                window.fill([63, 191, 255])
                window.blit(game_win_pic, [0, ny])
                time = 0
            else:
                level += 1
                map_list, all_prize = read_file('map' + str(level) + '.txt')
                score = 0
                score_text = font.render('Score: ' + str(score) + '/' + str(all_prize), True, [255, 242, 0])
                time = 20
                timer_text = font.render('Time: ' + str(time), True, [255, 242, 0])
                win = False
    else:
        window.blit(game_over_pic, [0,0])
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        elif event.type == pygame.KEYDOWN and not game_over and not win:
            next_row, next_col = next_step(event, p_row, p_col)
            p_row, p_col, next_row, next_col, score, win = move_player(map_list, p_row, p_col, next_row, next_col, score, win)
            score_text = font.render('Score: ' + str(score) + '/' + str(all_prize), True, [255, 242, 0])
        elif event.type == pygame.USEREVENT:
            time -= 1

            timer_text = font.render('Time: ' + str(time), True, [255, 242, 0])
    if time <= 0 and not win:
        game_over = True
        if time == -5:
            run = False
    if pygame.mouse.get_focused():
        pos = pygame.mouse.get_pos()
        window.blit(cursor, pos)
    clock.tick(60)
    pygame.display.flip()
pygame.quit()
quit()
